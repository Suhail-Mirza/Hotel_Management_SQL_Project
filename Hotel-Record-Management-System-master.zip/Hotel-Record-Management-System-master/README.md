# Hotel-Record-Management-System
This was done as a course project in Database Management System Course.

Read Project synopsis.pdf and SQL Queries.pdf  for more details
